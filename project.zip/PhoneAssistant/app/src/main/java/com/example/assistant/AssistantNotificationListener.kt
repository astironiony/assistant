package com.example.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class AssistantNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
        activeNotifications?.forEach { NotificationStore.put(it) }
    }

    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        if (e.getString("android.title") != null) NotificationStore.put(sbn)
        // TODO: здесь можно автоматически вызывать ИИ (авто-ответы, фильтры)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotificationStore.remove(sbn.key)
    }

    companion object { var instance: AssistantNotificationListener? = null }
}
