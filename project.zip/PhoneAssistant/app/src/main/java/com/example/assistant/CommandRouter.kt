package com.example.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle

/**
 * Шаблонные команды. Позже сюда подключим ИИ: он будет превращать
 * свободную фразу в одну из этих команд (см. TODO внизу).
 */
object CommandRouter {

    fun handle(ctx: Context, raw: String): String {
        val t = raw.trim()
        val l = t.lowercase()
        return when {
            l.startsWith("открой ") -> openApp(ctx, t.substring(7).trim())
            l == "прочитай уведомления" -> readNotifications()
            l.startsWith("ответь ") -> {
                // формат: "ответь Иван: привет, скоро буду"
                val body = t.substring(7)
                val i = body.indexOf(':')
                if (i < 0) "Формат: ответь Имя: текст"
                else reply(ctx, body.substring(0, i).trim(), body.substring(i + 1).trim())
            }
            l.startsWith("нажми ") -> {
                val ok = AssistantAccessibilityService.instance?.clickByText(t.substring(6).trim())
                when (ok) { null -> "Включите спец. возможности"; true -> "Нажато"; else -> "Не нашёл элемент" }
            }
            l.startsWith("напечатай ") -> {
                val ok = AssistantAccessibilityService.instance?.typeText(t.substring(10))
                if (ok == true) "Готово" else "Нет активного поля ввода"
            }
            l == "назад" -> global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            l == "домой" -> global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            l == "последние" -> global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            else -> "Не понял команду" // TODO: отправить фразу в ИИ → получить команду
        }
    }

    private fun global(action: Int): String {
        val s = AssistantAccessibilityService.instance ?: return "Включите спец. возможности"
        return if (s.performGlobalAction(action)) "Готово" else "Не удалось"
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "Приложение «$name» не найдено"
        val intent = pm.getLaunchIntentForPackage(app.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return "Не могу запустить"
        ctx.startActivity(intent)
        return "Открываю ${app.loadLabel(pm)}"
    }

    private fun readNotifications(): String {
        if (AssistantNotificationListener.instance == null) return "Выдайте доступ к уведомлениям"
        val list = NotificationStore.all().take(10)
        if (list.isEmpty()) return "Уведомлений нет"
        return list.joinToString("\n") {
            val e = it.notification.extras
            "• ${e.getString("android.title")}: ${e.getCharSequence("android.text") ?: ""}"
        }
    }

    /** Ответ на уведомление мессенджера через встроенную кнопку «Ответить» */
    private fun reply(ctx: Context, contact: String, text: String): String {
        val sbn = NotificationStore.findByTitle(contact) ?: return "Нет уведомления от «$contact»"
        val action = sbn.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
            ?: return "В этом уведомлении нет быстрого ответа"
        val input = action.remoteInputs[0]
        val intent = Intent()
        val bundle = Bundle().apply { putCharSequence(input.resultKey, text) }
        RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
        return try {
            action.actionIntent.send(ctx, 0, intent)
            "Ответ отправлен: $contact"
        } catch (e: Exception) { "Ошибка: ${e.message}" }
    }

    // TODO ИИ: suspend fun askAi(userText: String): String — отправить запрос в API (Claude и т.п.),
    // попросить вернуть одну строку-команду из списка выше, затем передать её в handle().
}
