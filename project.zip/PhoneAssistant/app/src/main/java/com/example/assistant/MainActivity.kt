package com.example.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var output: TextView

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (text != null) { input.setText(text); run() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }; root.addView(this)
        }

        btn("1. Доступ к уведомлениям") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("2. Спец. возможности (управление)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        input = EditText(this).apply { hint = "Команда, напр.: открой telegram" }
        root.addView(input)
        btn("Выполнить") { run() }
        btn("🎤 Голос") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            })
        }
        output = TextView(this).apply { textSize = 16f }
        root.addView(ScrollView(this).apply { addView(output) })
        setContentView(root)
    }

    private fun run() {
        val cmd = input.text.toString()
        output.text = CommandRouter.handle(this, cmd)
    }
}
