package com.example.assistant

import android.service.notification.StatusBarNotification

data class Msg(val key: String, val app: String, val title: String, val text: String)

object NotificationStore {
    private val items = LinkedHashMap<String, StatusBarNotification>()

    @Synchronized fun put(sbn: StatusBarNotification) { items[sbn.key] = sbn }
    @Synchronized fun remove(key: String) { items.remove(key) }

    @Synchronized fun all(): List<StatusBarNotification> = items.values.toList().reversed()

    @Synchronized fun findByTitle(name: String): StatusBarNotification? =
        all().firstOrNull {
            it.notification.extras.getString("android.title")?.contains(name, true) == true
        }
}
