# PhoneAssistant
Полный проект. Сборка: gradle assembleDebug -> app/build/outputs/apk/debug/app-debug.apk
